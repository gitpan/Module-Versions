# ==============================================================================
# $Id: 02_app.pl 27 2006-09-19 10:10:54Z HVRTWall $
# Copyright (c) 2005-2006 Thomas Walloschke (thw@cpan.org). All rights reserved.
# Example 01 - Module::Versions
# ==============================================================================

# ----------------------------------------------
print STDERR "$0: ... tbd - comes with next version.\n"
# ----------------------------------------------

__END__

=head1 NAME

01_app - Example 01 - Module::Versions

=head1 AUTHOR

Thomas Walloschke E<lt>thw@cpan.orgE<gt>.

=head1 COPYRIGHT AND LICENSE

Copyright (c) 2006 Thomas Walloschke (thw@cpan.org).All rights reserved.

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself, either Perl version 5.8.6 or,
at your option, any later version of Perl 5 you may have available.

=head1 DATE

Last changed $Date: 2006-09-19 12:10:54 +0200 (Di, 19 Sep 2006) $.

=cut



